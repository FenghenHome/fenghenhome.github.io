import time

node_plan = 1

def getRowMap():
	return {} # if your db row "encrypt" means "method", write {"encrypt": "method"}

def getKeys(key_list):
	#return key_list
	return key_list + ['plan', 'expired_at']

def isPlan(row):
	#return True
	return row['plan'] >= node_plan

def isExpire(row):
	#return True
	return row['expired_at'] >= int(time.strftime("%Y%m%d", time.localtime()))

def isTurnOn(row):
	#return True
	return isPlan(row) and isExpire(row)

